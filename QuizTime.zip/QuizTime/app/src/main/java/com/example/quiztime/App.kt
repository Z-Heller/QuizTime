package com.example.quiztime

import android.app.Application
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner

class App : Application() {
    override fun onCreate() {
        super.onCreate()

        val settings = getSharedPreferences("Login", 0)
        val sfxToggled: Int = settings.getInt("sfxToggled", 0)
        if (sfxToggled == 1) {
            settings.edit().putInt("sfx", 1).apply()
            settings.edit().putInt("sfxToggled", 0).apply()
        }

        var lifecycleEventObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> {

                    val settings = getSharedPreferences("Login", 0)
                    val musicon: Int = settings.getInt("bgmusic", 1)
                    val sfxon : Int = settings.getInt("sfx", 1)

                    if (musicon == 1) {
                        val pause = Intent()
                        pause.action = "PAUSE"
                        sendBroadcast(pause)
                    }
                    if (sfxon == 1) {
                        settings.edit().putInt("sfx", 0).apply()
                        settings.edit().putInt("sfxToggled", 1).apply()
                    }else settings.edit().putInt("sfxToggled", 0).apply()
                }
                Lifecycle.Event.ON_RESUME -> {

                    val settings = getSharedPreferences("Login", 0)
                    val musicon: Int = settings.getInt("bgmusic", 1)
                    val sfxon : Int = settings.getInt("sfx", 1)

                    if (musicon == 1) {
                        val resume = Intent()
                        resume.action = "RESUME"
                        sendBroadcast(resume)
                    }

                    val sfxToggled: Int = settings.getInt("sfxToggled", 0)

                    if (sfxToggled == 1) {
                        settings.edit().putInt("sfx", 1).apply()
                        settings.edit().putInt("sfxToggled", 0).apply()
                    }
                }
                else -> {}
            }
        }

        ProcessLifecycleOwner.get().lifecycle.addObserver(lifecycleEventObserver)
    }
}