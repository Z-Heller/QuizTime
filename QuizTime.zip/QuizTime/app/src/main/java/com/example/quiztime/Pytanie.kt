package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quiztime.classes.Quiz

class Pytanie : AppCompatActivity(), View.OnClickListener {
    var mMediaPlayer: MediaPlayer? = null
    lateinit var value : Quiz
    lateinit var tytul : TextView
    lateinit var tresc : TextView
    lateinit var odpA : TextView
    lateinit var odpB : TextView
    lateinit var odpC : TextView
    lateinit var odpD : TextView
    lateinit var odpP : TextView
    lateinit var odpW : String
    lateinit var nr_pytania : TextView
    lateinit var tryb : String

    private var numer = 0
    private var wynik = 0
    private var mLastClickTime: Long = 0
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pytanie)


        value = intent.getParcelableExtra("quiz")!!
        tryb = intent.getStringExtra("tryb").toString()

        tytul = findViewById(R.id.TytulQuizu)
        tresc = findViewById<TextView>(R.id.tresc)
        odpA = findViewById<TextView>(R.id.odpA)
        odpB = findViewById<TextView>(R.id.odpB)
        odpC = findViewById<TextView>(R.id.odpC)
        odpD = findViewById<TextView>(R.id.odpD)
        nr_pytania = findViewById<TextView>(R.id.nr_pytania)

        tytul.setText(value.nazwa)

        //Załadowanie pierwszych pytań
        tresc.setText(value.pytania.get(numer).tresc)
        odpA.setText(value.pytania.get(numer).odpA)
        odpB.setText(value.pytania.get(numer).odpB)
        odpC.setText(value.pytania.get(numer).odpC)
        odpD.setText(value.pytania.get(numer).odpD)
        nr_pytania.setText("Pytanie " + (numer+1) + ":")

        odpA.setOnClickListener(this)
        odpB.setOnClickListener(this)
        odpC.setOnClickListener(this)
        odpD.setOnClickListener(this)

    }
    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 2000){
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();
        //Tu sprawdzam ktora odp jest wybrana
        when (v.id) {
            R.id.odpA -> {
                odpW = value.pytania.get(numer).odpA
            }
            R.id.odpB -> {
                odpW = value.pytania.get(numer).odpB
            }
            R.id.odpC -> {
                odpW = value.pytania.get(numer).odpC
            }
            R.id.odpD -> {
                odpW = value.pytania.get(numer).odpD
            }
            else -> {
                //TODO Ale tu nic sie nie bedzie dzialo
            }
        }

        val settings = getSharedPreferences("Login", 0)
        val sfxon : Int = settings.getInt("sfx", 1)

        //Poprawnosc
        if(odpW == value.pytania.get(numer).poprawna) {
            wynik = wynik + 1
            if(sfxon == 1){
                mMediaPlayer = MediaPlayer.create(this, R.raw.correct)
                mMediaPlayer!!.isLooping = false
                mMediaPlayer!!.start()
            }
            //Przy poprawnej podswietlamy button na zielono
            if(v.id==R.id.odpA) odpA.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpB) odpB.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpC) odpC.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpD) odpD.setBackgroundColor(Color.GREEN)

        } else
        {
            if(sfxon == 1) {
                mMediaPlayer = MediaPlayer.create(this, R.raw.wrong)
                mMediaPlayer!!.isLooping = false
                mMediaPlayer!!.start()
            }
            //Przy złej podswietlamy złą która wybralismy
            if(v.id==R.id.odpB) odpB.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpA) odpA.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpC) odpC.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpD) odpD.setBackgroundColor(Color.rgb(128,0,0))
            //Oraz poprawną
            when (value.pytania.get(numer).poprawna) {
                value.pytania.get(numer).odpA -> {
                    odpA.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpB -> {
                    odpB.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpC -> {
                    odpC.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpD -> {
                    odpD.setBackgroundColor(Color.GREEN)
                }
            }
        }

        Handler(Looper.getMainLooper()).postDelayed(
            {
                if(numer + 1 == value.pytania.size){
                    val intent = Intent(this, Wyniki::class.java)
                    intent.putExtra("wynik", wynik)
                    intent.putExtra("quiz", value)
                    intent.putExtra("tryb", tryb)
                    mMediaPlayer!!.release()
                    startActivity(intent)
                    finish()
                }
                else {
                    //Przywrocenie kolorow buttonow
                    odpA.setBackgroundColor(Color.rgb(255,77,24))
                    odpB.setBackgroundColor(Color.rgb(255,77,24))
                    odpC.setBackgroundColor(Color.rgb(255,77,24))
                    odpD.setBackgroundColor(Color.rgb(255,77,24))
                    //Kolejne pytanie
                    numer = numer + 1
                    tresc.setText(value.pytania.get(numer).tresc)
                    odpA.setText(value.pytania.get(numer).odpA)
                    odpB.setText(value.pytania.get(numer).odpB)
                    odpC.setText(value.pytania.get(numer).odpC)
                    odpD.setText(value.pytania.get(numer).odpD)
                    nr_pytania.setText("Pytanie " + (numer+1) + ":")
                }
            },
            2000 // value in milliseconds
        )

    }

    override fun onBackPressed() {
        super.onBackPressed()
        if(mMediaPlayer!=null) mMediaPlayer!!.release()
        finish()
    }

}