package com.example.quiztime

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.CompoundButton
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class Ustawienia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ustawienia)

        val settings = getSharedPreferences("Login", 0)

        val muzyka = findViewById<Switch>(R.id.Background)
        val musicon: Int = settings.getInt("bgmusic", 1)

        if (musicon == 1) muzyka.setChecked(true)
        else muzyka.setChecked(false)

        muzyka.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            run {
                val musicon: Int = settings.getInt("bgmusic", 1);
                if (musicon == 1) {
//                    val intent = Intent(this, BgMusic::class.java)
//                    this.stopService(intent)
                    val pause = Intent()
                    pause.action = "PAUSE"
                    sendBroadcast(pause)
                    settings.edit().putInt("bgmusic", 0).apply()
                } else {
                    val intent = Intent(this, BgMusic::class.java)
                    this.startService(intent)
                    settings.edit().putInt("bgmusic", 1).apply()
                }
            }
        })


        val efekty = findViewById<Switch>(R.id.SFX)
        val sfxon: Int = settings.getInt("sfx", 1)

        if (sfxon == 1) efekty.setChecked(true)
        else efekty.setChecked(false)

        efekty.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            run {
                val sfxon: Int = settings.getInt("sfx", 1);
                if (sfxon == 1) {
                    settings.edit().putInt("sfx", 0).apply()
                } else {
                    settings.edit().putInt("sfx", 1).apply()
                    var mMediaPlayer = MediaPlayer.create(this, R.raw.correct)
                    mMediaPlayer!!.isLooping = false
                    mMediaPlayer!!.start()
                    if(!mMediaPlayer!!.isPlaying) mMediaPlayer!!.release()
                }
            }
        })
    }
}