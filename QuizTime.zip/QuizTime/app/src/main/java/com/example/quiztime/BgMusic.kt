package com.example.quiztime

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.IBinder

private val receiver = BgMusic().BgMusicReceiver()


class BgMusic : Service() {
    companion object{
        var running : Boolean = false
    }

    internal lateinit var mplayer: MediaPlayer
    var length : Int = 0

    override fun onBind(arg0: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
//        running = true
        val filter = IntentFilter()
        filter.addAction("PAUSE")
        filter.addAction("RESUME")
        filter.addAction("STOP")

        val receiver = BgMusicReceiver()
        registerReceiver(receiver, filter)

        mplayer = MediaPlayer.create(this, R.raw.background)
        mplayer.isLooping = true
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        mplayer.start()
        return START_NOT_STICKY;
    }

    fun onStart(){
        mplayer.start()
    }


    fun onStop() {
        mplayer.stop()
        mplayer.release()
    }

    fun onPause() {
        length=mplayer.getCurrentPosition()
        if (mplayer.isPlaying == true) {
            mplayer.pause()
        }
    }

    fun onResume() {
        mplayer.seekTo(length)
        if (mplayer.isPlaying == false) {
            mplayer.start()
        }
    }


    override fun onDestroy() {
        mplayer.stop()
        mplayer.release()
        unregisterReceiver(receiver);
        running = false
    }

    inner class BgMusicReceiver : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if(action == "PAUSE"){
                onPause()
            }else if(action == "RESUME"){
                onResume()
            }else if(action == "STOP"){
                onStop()
            }else if(action == "DESTROY"){
                onDestroy()
            }
        }
    }

}

