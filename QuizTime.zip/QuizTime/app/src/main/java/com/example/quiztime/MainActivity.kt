package com.example.quiztime

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val settings = getSharedPreferences("Login", 0)
        if(settings.contains("username")) {
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
            finish()
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
            val username = findViewById<EditText>(R.id.username)
            if(username.text.toString().trim().length == 0) {
                val text = "Nazwa użytkownika nie może być pusta"
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show()
            }else if(username.text.toString().trim().length > 20) {
                val text = "Nazwa użytkownika nie może przekraczać 20 znaków"
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show()
            }
            else{
                settings.edit().putString("username", username.text.toString().trim()).apply()
                val intent = Intent(this, Dashboard::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}