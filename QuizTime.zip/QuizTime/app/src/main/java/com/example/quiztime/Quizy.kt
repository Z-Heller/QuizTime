package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import com.example.quiztime.classes.Quiz
import com.example.quiztime.classes.bazaQuizow

class Quizy : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quizy)

        val bundle = intent.extras
        var value = ""
        if (bundle != null) value = bundle.getString("kategoria").toString()

        val tytul = findViewById<TextView>(R.id.Kategoria)
        tytul.setText(value)

        val listView = findViewById<ListView>(R.id.list)

        val listaQuizow = bazaQuizow.getQuizy(value)

        class QuizAdapter(context: Context, @LayoutRes private val layoutResource: Int, private val listaKategorii: ArrayList<Quiz>):
            ArrayAdapter<Quiz>(this, R.layout.userbutton, listaKategorii) {

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return createViewFromResource(position, convertView, parent)
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
                return createViewFromResource(position, convertView, parent)
            }

            private fun createViewFromResource(position: Int, convertView: View?, parent: ViewGroup?): View {
                val bttn: Button = convertView as Button? ?: LayoutInflater.from(context).inflate(layoutResource, parent, false) as Button
                bttn.text = listaQuizow.get(position).nazwa
                bttn.setOnClickListener {
                    val intent = Intent(context, StartQuizu::class.java)
                    intent.putExtra("quiz", listaQuizow.get(position))
                    startActivity(intent)
                }
                return bttn
            }
        }

        listView.adapter = QuizAdapter(this, R.layout.userbutton, listaQuizow)

    }
}