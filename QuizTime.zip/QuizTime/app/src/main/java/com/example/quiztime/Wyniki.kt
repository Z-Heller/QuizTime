package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.quiztime.classes.Quiz

class Wyniki : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wyniki)
        val tryb : String = intent.getStringExtra("tryb").toString()
        val wynik : Int = intent.getIntExtra("wynik", 0)
        val wynikText = findViewById<TextView>(R.id.Wynik)
        wynikText.setText(wynik.toString()+"/10")
        val tytul = findViewById<TextView>(R.id.TytulQuizu)

        var quiz : Quiz = intent.getParcelableExtra("quiz")!!

        tytul.setText(quiz.nazwa)

        var scoreLabel : String = quiz.kategoria+"-"+quiz.nazwa+"-"+tryb
        scoreLabel = scoreLabel.replace(' ', '_')

        val highScore = getSharedPreferences("HighScore", 0)
        if(highScore.contains(scoreLabel)) {
            if(highScore.getInt(scoreLabel, 0) < wynik){
                highScore.edit().putInt(scoreLabel, wynik).apply()
            }
        }else{
            highScore.edit().putInt(scoreLabel, wynik).apply()
        }

        val prevBest = findViewById<TextView>(R.id.Best)
        prevBest.setText(highScore.getInt(scoreLabel, 0).toString()+"/10")

        val wypiszTryb = findViewById<TextView>(R.id.Tryb)
        if(tryb == "Time") wypiszTryb.setText("na czas")

        val button1 = findViewById<Button>(R.id.Powtorz)
        button1.setOnClickListener {
            val intent = Intent(this, StartQuizu::class.java)
            intent.putExtra("quiz", quiz)
            startActivity(intent)
            finish()
        }
        val button2 = findViewById<Button>(R.id.Kolejny)
        button2.setOnClickListener {
            val intent = Intent(this, Kategorie::class.java)
            startActivity(intent)
            finish()
        }
    }
}