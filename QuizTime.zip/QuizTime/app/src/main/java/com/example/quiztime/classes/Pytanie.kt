package com.example.quiztime.classes

import android.os.Parcel
import android.os.Parcelable

data class Pytanie(
    val tresc: String,
    val odpA: String,
    val odpB: String,
    val odpC: String,
    val odpD: String,
    val poprawna: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(tresc)
        parcel.writeString(odpA)
        parcel.writeString(odpB)
        parcel.writeString(odpC)
        parcel.writeString(odpD)
        parcel.writeString(poprawna)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Pytanie> {
        override fun createFromParcel(parcel: Parcel): Pytanie {
            return Pytanie(parcel)
        }

        override fun newArray(size: Int): Array<Pytanie?> {
            return arrayOfNulls(size)
        }
    }
}