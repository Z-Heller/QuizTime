package com.example.quiztime

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity


class Kategorie : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kategorie)

        val listaKategorii = ArrayList<String>()

        listaKategorii.add("Wiedza ogólna")
        listaKategorii.add("Informatyka")
        listaKategorii.add("Geografia")
        listaKategorii.add("Gry komputerowe")


        val listView = findViewById<ListView>(R.id.list)

        class KategoriaAdapter(context: Context, @LayoutRes private val layoutResource: Int, private val listaKategorii: ArrayList<String>):
            ArrayAdapter<String>(this, R.layout.userbutton, listaKategorii) {

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return createViewFromResource(position, convertView, parent)
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
                return createViewFromResource(position, convertView, parent)
            }

            private fun createViewFromResource(position: Int, convertView: View?, parent: ViewGroup?): View{
                val bttn: Button = convertView as Button? ?: LayoutInflater.from(context).inflate(layoutResource, parent, false) as Button
                bttn.text = listaKategorii.get(position)
                bttn.setOnClickListener {
                    val intent = Intent(context, Quizy::class.java)
                    val bundle = Bundle()
                    bundle.putString("kategoria", listaKategorii.get(position))
                    intent.putExtras(bundle)
                    startActivity(intent)
                }
                return bttn
            }
        }

        listView.adapter = KategoriaAdapter(this, R.layout.userbutton, listaKategorii)

    }
}