package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.os.*
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quiztime.classes.Quiz

class PytanieCzas : AppCompatActivity(), View.OnClickListener  {
    var mMediaPlayer: MediaPlayer? = null

    lateinit var value : Quiz
    lateinit var tytul : TextView
    lateinit var tresc : TextView
    lateinit var odpA : TextView
    lateinit var odpB : TextView
    lateinit var odpC : TextView
    lateinit var odpD : TextView
    lateinit var skip : TextView
    lateinit var odpW : String
    lateinit var nr_pytania : TextView
    lateinit var tryb : String

    private var mLastClickTime: Long = 0
    private var numer = 0
    private var wynik = 0

    companion object {
        lateinit var timer: CountDownTimer
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pytanie_czas)


        value = intent.getParcelableExtra("quiz")!!
        tryb = intent.getStringExtra("tryb").toString()

        tytul = findViewById(R.id.TytulQuizu)
        tresc = findViewById<TextView>(R.id.tresc)
        odpA = findViewById<TextView>(R.id.odpA)
        odpB = findViewById<TextView>(R.id.odpB)
        odpC = findViewById<TextView>(R.id.odpC)
        odpD = findViewById<TextView>(R.id.odpD)
        skip = findViewById<TextView>(R.id.Skip)
        nr_pytania = findViewById<TextView>(R.id.nr_pytania)

        tytul.setText(value.nazwa)
        val TimerText = findViewById<TextView>(R.id.Timer)
        TimerText.setBackgroundColor(Color.rgb(51,204,51))

        val settings = getSharedPreferences("Login", 0)

        timer = object: CountDownTimer(11000, 1000) {
            var count : Int = 11
            override fun onTick(millisUntilFinished: Long) {
                count --
                val TimerText = findViewById<TextView>(R.id.Timer)
                TimerText.setText("Czas: "+count.toString())
                if(count==3) TimerText.setBackgroundColor(Color.rgb(255,0,0))
                if(count in 1..3){
                    val sfxon : Int = settings.getInt("sfx", 1)
                    if(sfxon == 1) {
                        mMediaPlayer = MediaPlayer.create(this@PytanieCzas, R.raw.beep)
                        mMediaPlayer!!.isLooping = false
                        mMediaPlayer!!.start()
                    }
                }
                if(count==0){
                    val sfxon : Int = settings.getInt("sfx", 1)
                    if(sfxon == 1) {
                        mMediaPlayer = MediaPlayer.create(this@PytanieCzas, R.raw.alarm)
                        mMediaPlayer!!.isLooping = false
                        mMediaPlayer!!.start()
                    }

                    val popr : String = value.pytania.get(numer).poprawna
                    if(odpA.text == popr) odpA.setBackgroundColor(Color.GREEN)
                    if(odpB.text == popr) odpB.setBackgroundColor(Color.GREEN)
                    if(odpC.text == popr) odpC.setBackgroundColor(Color.GREEN)
                    if(odpD.text == popr) odpD.setBackgroundColor(Color.GREEN)
                }
            }

            override fun onFinish() {
                val skip = findViewById<Button>(R.id.Skip)
                skip.performClick()
            }
        }
        timer.start()

        //Załadowanie pierwszych pytań
        tresc.setText(value.pytania.get(numer).tresc)
        odpA.setText(value.pytania.get(numer).odpA)
        odpB.setText(value.pytania.get(numer).odpB)
        odpC.setText(value.pytania.get(numer).odpC)
        odpD.setText(value.pytania.get(numer).odpD)
        nr_pytania.setText("Pytanie " + (numer+1) + ":")

        odpA.setOnClickListener(this)
        odpB.setOnClickListener(this)
        odpC.setOnClickListener(this)
        odpD.setOnClickListener(this)
        skip.setOnClickListener(this)

    }
    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 2000){
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();
        timer.cancel()

        //Tu sprawdzam ktora odp jest wybrana
        when (v.id) {
            R.id.odpA -> {
                odpW = value.pytania.get(numer).odpA
            }
            R.id.odpB -> {
                odpW = value.pytania.get(numer).odpB
            }
            R.id.odpC -> {
                odpW = value.pytania.get(numer).odpC
            }
            R.id.odpD -> {
                odpW = value.pytania.get(numer).odpD
            }
            else -> {
                odpW = "skip"
            }
        }

        val settings = getSharedPreferences("Login", 0)
        val sfxon : Int = settings.getInt("sfx", 1)

        //Poprawnosc
        if(odpW == value.pytania.get(numer).poprawna) {
            wynik = wynik + 1
            if(sfxon == 1){
                mMediaPlayer = MediaPlayer.create(this, R.raw.correct)
                mMediaPlayer!!.isLooping = false
                mMediaPlayer!!.start()
            }
            //Przy poprawnej podswietlamy button na zielono
            if(v.id==R.id.odpA) odpA.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpB) odpB.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpC) odpC.setBackgroundColor(Color.GREEN)
            if(v.id==R.id.odpD) odpD.setBackgroundColor(Color.GREEN)

        } else
        {
            if(sfxon == 1 && odpW!="skip") {
                mMediaPlayer = MediaPlayer.create(this, R.raw.wrong)
                mMediaPlayer!!.isLooping = false
                mMediaPlayer!!.start()
            }
            //Przy złej podswietlamy złą która wybralismy
            if(v.id==R.id.odpB) odpB.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpA) odpA.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpC) odpC.setBackgroundColor(Color.rgb(128,0,0))
            if(v.id==R.id.odpD) odpD.setBackgroundColor(Color.rgb(128,0,0))
            //Oraz poprawną
            when (value.pytania.get(numer).poprawna) {
                value.pytania.get(numer).odpA -> {
                    odpA.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpB -> {
                    odpB.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpC -> {
                    odpC.setBackgroundColor(Color.GREEN)
                }
                value.pytania.get(numer).odpD -> {
                    odpD.setBackgroundColor(Color.GREEN)
                }
            }
        }

        Handler(Looper.getMainLooper()).postDelayed(
            {
                val settings = getSharedPreferences("Login", 0)

                if(numer + 1 == value.pytania.size){
                    timer.cancel()
                    val intent = Intent(this, Wyniki::class.java)
                    intent.putExtra("wynik", wynik)
                    intent.putExtra("quiz", value)
                    intent.putExtra("tryb", tryb)
                    mMediaPlayer!!.release()
                    startActivity(intent)
                    finish()
                }
                else {
                    //Przywrocenie kolorow buttonow
                    timer.cancel()
                    timer = object: CountDownTimer(11000, 1000) {
                        var count : Int = 11
                        override fun onTick(millisUntilFinished: Long) {
                            count --
                            val TimerText = findViewById<TextView>(R.id.Timer)
                            TimerText.setText("Czas: "+count.toString())
                            if(count==3) TimerText.setBackgroundColor(Color.rgb(255,0,0))
                            if(count in 1..3){
                                val sfxon : Int = settings.getInt("sfx", 1)
                                if(sfxon == 1) {
                                    mMediaPlayer = MediaPlayer.create(this@PytanieCzas, R.raw.beep)
                                    mMediaPlayer!!.isLooping = false
                                    mMediaPlayer!!.start()
                                }
                            }
                            if(count==0){
                                if(sfxon == 1) {
                                    mMediaPlayer = MediaPlayer.create(this@PytanieCzas, R.raw.alarm)
                                    mMediaPlayer!!.isLooping = false
                                    mMediaPlayer!!.start()
                                }

                                val popr : String = value.pytania.get(numer).poprawna
                                if(odpA.text == popr) odpA.setBackgroundColor(Color.GREEN)
                                if(odpB.text == popr) odpB.setBackgroundColor(Color.GREEN)
                                if(odpC.text == popr) odpC.setBackgroundColor(Color.GREEN)
                                if(odpD.text == popr) odpD.setBackgroundColor(Color.GREEN)
                            }
                        }

                        override fun onFinish() {
                            val skip = findViewById<Button>(R.id.Skip)
                            skip.performClick()
                        }
                    }
                    timer.start()
                    val TimerText = findViewById<TextView>(R.id.Timer)
                    TimerText.setBackgroundColor(Color.rgb(51,204,51))
                    odpA.setBackgroundColor(Color.rgb(255,77,24))
                    odpB.setBackgroundColor(Color.rgb(255,77,24))
                    odpC.setBackgroundColor(Color.rgb(255,77,24))
                    odpD.setBackgroundColor(Color.rgb(255,77,24))
                    //Kolejne pytanie
                    numer = numer + 1
                    tresc.setText(value.pytania.get(numer).tresc)
                    odpA.setText(value.pytania.get(numer).odpA)
                    odpB.setText(value.pytania.get(numer).odpB)
                    odpC.setText(value.pytania.get(numer).odpC)
                    odpD.setText(value.pytania.get(numer).odpD)
                    nr_pytania.setText("Pytanie " + (numer+1) + ":")
                }
            },
            2000 // value in milliseconds
        )

    }

    override fun onBackPressed() {
        super.onBackPressed()
        timer.cancel()
        if(mMediaPlayer!=null) mMediaPlayer!!.release()
        finish()
    }


}