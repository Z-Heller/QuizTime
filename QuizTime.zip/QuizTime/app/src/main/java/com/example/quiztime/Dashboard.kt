package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.media.MediaPlayer

class Dashboard : AppCompatActivity() {
    var mplayer: MediaPlayer? = null
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val settings = getSharedPreferences("Login", 0)
        val witaj = findViewById<TextView>(R.id.Kategoria)
        witaj.setText("Witaj " + settings.getString("username", null) + "!")

        if(settings.contains("bgmusic")) {
            val musicon : Int = settings.getInt("bgmusic", 1)
            if (musicon == 1) {
                val intent = Intent(this, BgMusic::class.java)
                this.startService(intent)
            }
        }else{
            settings.edit().putInt("bgmusic", 1).apply()
            val intent = Intent(this, BgMusic::class.java)
            this.startService(intent)
        }

        if(!settings.contains("sfx")) {
            settings.edit().putInt("sfx", 1).apply()
        }

        val button1 = findViewById<Button>(R.id.rozpocznij)
        button1.setOnClickListener {
            val intent = Intent(this, Kategorie::class.java)
            startActivity(intent)
        }

        val button2 = findViewById<Button>(R.id.ustawienia)
        button2.setOnClickListener {
            val intent = Intent(this, Ustawienia::class.java)
            startActivity(intent)
        }


        val button3 = findViewById<Button>(R.id.wyjdz)
        button3.setOnClickListener {
            finish()
        }

    }
}