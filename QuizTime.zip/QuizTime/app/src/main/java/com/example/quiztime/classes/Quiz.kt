package com.example.quiztime.classes

import android.os.Parcel
import android.os.Parcelable

data class Quiz (
    val nazwa: String,
    val kategoria: String,
    val pytania: ArrayList<Pytanie>,
    val img: Int
    ) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.createTypedArrayList(Pytanie.CREATOR)?:ArrayList(),
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(nazwa)
        parcel.writeString(kategoria)
        parcel.writeTypedList(pytania);
        parcel.writeInt(img)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Quiz> {
        override fun createFromParcel(parcel: Parcel): Quiz {
            return Quiz(parcel)
        }

        override fun newArray(size: Int): Array<Quiz?> {
            return arrayOfNulls(size)
        }
    }
}
