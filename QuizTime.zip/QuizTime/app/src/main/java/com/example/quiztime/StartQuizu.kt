package com.example.quiztime

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.example.quiztime.classes.Quiz
import com.example.quiztime.classes.bazaQuizow

class StartQuizu : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_quizu)

        var value : Quiz = intent.getParcelableExtra("quiz")!!
        val tytul = findViewById<TextView>(R.id.TytulQuizu)
        tytul.setText(value.nazwa)

        val img = findViewById<ImageView>(R.id.Obraz)
        img.setImageResource(value.img)

        val radios = findViewById<RadioGroup>(R.id.radioGroup)

        val button1 = findViewById<Button>(R.id.Rozpocznij)
        button1.setOnClickListener {
            val tryb = radios.checkedRadioButtonId
            var intent = Intent(this, Pytanie::class.java)
            if(resources.getResourceEntryName(tryb) == "Time"){
                intent = Intent(this, PytanieCzas::class.java)
            }
            intent.putExtra("quiz", value)
            intent.putExtra("tryb", resources.getResourceEntryName(tryb))
            startActivity(intent)
            finish()
        }

    }
}